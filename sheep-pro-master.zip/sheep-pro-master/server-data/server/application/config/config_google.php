<?php
/* 
	Account Used: 
	Username: appdevelopment50@gmail.com
	Pasasword: techno@123	
*/
$config['application_name'] = 'SheepTimer';
$config['client_id']='528139205075-let9epjgelhg625gbk6onsl21a7v7qp4.apps.googleusercontent.com';
$config['client_secret'] = 'VWIBihBXcVK8adt5G9PGdEdx';
$config['redirect_uri'] = base_url('booking/index');
$config['api_key'] = 'AIzaSyBjmRmbsKbKDY_JoLWnzlVrjKr06NdD6rM';
?>
