			<tr style="border-bottom:1px solid #eee;text-align:center;background:#3c8dbc;">
					<td>
						<table width="100%">
							<tbody>
								<tr style="background: #3c8dbc;
    color: white;">
									<td style="text-align: center">
										Address: 1455 Carapook Road, Carapook VIC, 3312.<br/>
										Ph/Fax: (03) 55 798 585, Mark: 0428 386 924, Mark: 0428 386 924<br/>
										Email mark@sheeppro.com.au
									</td>
								</tr>
							<!-- 	<tr style="text-align:center;">
									<td style="color:white;text-align: left;">
										contact@sheeptimer.com
									</td>
									<td style="color:white;text-align: right">
										© Copyright <?php echo date('Y'); ?> SheepTimer. 
									</td>
								</tr>	 -->							
							</tbody>
						</table>
					</td>
				</tr>
			</tbody>
		</table>		
	</body>
</html>