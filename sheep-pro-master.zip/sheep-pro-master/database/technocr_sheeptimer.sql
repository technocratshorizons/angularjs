-- Adminer 4.3.1 MySQL dump

SET NAMES utf8;
SET time_zone = '+00:00';
SET foreign_key_checks = 0;
SET sql_mode = 'NO_AUTO_VALUE_ON_ZERO';

DROP TABLE IF EXISTS `bookings`;
CREATE TABLE `bookings` (
  `booking_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `client_id` bigint(20) NOT NULL,
  `unavailable_dates` varchar(255) NOT NULL,
  `client_confirmation_email` tinyint(1) NOT NULL DEFAULT '0',
  `client_confirmation_sms` tinyint(1) NOT NULL DEFAULT '0',
  `notes` text NOT NULL,
  PRIMARY KEY (`booking_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO `bookings` (`booking_id`, `client_id`, `unavailable_dates`, `client_confirmation_email`, `client_confirmation_sms`, `notes`) VALUES
(1,	66,	'10-01-2018,17-01-2018,24-01-2018',	1,	1,	'Ok Great'),
(2,	67,	'16-01-2018,17-01-2018',	1,	1,	'dsfdsf'),
(3,	68,	'',	1,	1,	''),
(4,	69,	'26-01-2018',	1,	1,	'');

DROP TABLE IF EXISTS `joinings`;
CREATE TABLE `joinings` (
  `join_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `booking_id` bigint(20) NOT NULL,
  `joining_title` varchar(255) DEFAULT NULL,
  `number_of_sheep` varchar(255) NOT NULL,
  `scan_type` varchar(255) NOT NULL,
  `booking_date` varchar(255) NOT NULL,
  `time` varchar(255) NOT NULL,
  `scanner` varchar(255) NOT NULL,
  `room_in` varchar(255) NOT NULL,
  `room_out` varchar(255) NOT NULL,
  `introduced_days` varchar(255) NOT NULL,
  `joining_duration` varchar(255) NOT NULL,
  `room_free_days` varchar(255) NOT NULL,
  `date_to_scan` varchar(255) NOT NULL,
  `event_ids` text NOT NULL,
  `status` enum('pending','scheduled','completed','canceled','booking-pending') NOT NULL DEFAULT 'pending',
  `extra_date` varchar(255) NOT NULL,
  `google_delete` enum('Not','Yes') NOT NULL DEFAULT 'Not',
  `booking_date_end` varchar(255) NOT NULL,
  PRIMARY KEY (`join_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO `joinings` (`join_id`, `booking_id`, `joining_title`, `number_of_sheep`, `scan_type`, `booking_date`, `time`, `scanner`, `room_in`, `room_out`, `introduced_days`, `joining_duration`, `room_free_days`, `date_to_scan`, `event_ids`, `status`, `extra_date`, `google_delete`, `booking_date_end`) VALUES
(1,	1,	NULL,	'150',	'Single',	'2018-01-05T18:30:00.000Z',	'',	'65',	'2017-11-30T13:00:00.000Z',	'2017-12-21T13:00:00.000Z',	'38',	'22',	'17',	'2018-02-04T13:00:00.000Z',	'570ta4ks25tm9dop05kh47vei8',	'pending',	'2018-01-05T18:30:00.000Z',	'Not',	'2018-01-05T18:30:00.000Z'),
(2,	2,	NULL,	'200',	'Single',	'2018-01-05T00:00:00+11:00',	'',	'65',	'2018-01-05T00:00:00+11:00',	'2018-01-05T00:00:00+11:00',	'1',	'1',	'1',	'',	'',	'booking-pending',	'',	'Not',	'2018-01-05T00:00:00+11:00'),
(3,	3,	NULL,	'300',	'Single',	'2018-01-05T00:00:00+11:00',	'',	'65',	'2017-12-01T00:00:00+11:00',	'2017-12-15T00:00:00+11:00',	'36',	'-14',	'22',	'',	'',	'booking-pending',	'',	'Not',	'2018-01-05T00:00:00+11:00'),
(4,	4,	NULL,	'12121',	'Single',	'2018-01-05T00:00:00+11:00',	'',	',65',	'2018-01-05T00:00:00+11:00',	'2018-01-05T00:00:00+11:00',	'1',	'1',	'1',	'',	'',	'booking-pending',	'',	'Not',	'2018-01-05T00:00:00+11:00');

DROP TABLE IF EXISTS `users`;
CREATE TABLE `users` (
  `user_id` int(11) NOT NULL AUTO_INCREMENT,
  `user_type` enum('Admin','Client','Scanner') NOT NULL,
  `first_name` varchar(100) NOT NULL,
  `last_name` varchar(100) NOT NULL,
  `company` varchar(256) NOT NULL,
  `email` varchar(256) NOT NULL,
  `password` text NOT NULL,
  `secondary_email` varchar(256) DEFAULT NULL,
  `mobile_phone` varchar(50) NOT NULL,
  `landline_phone` varchar(50) DEFAULT NULL,
  `address_1` text,
  `address_2` text,
  `suburb` varchar(100) NOT NULL,
  `post_code` varchar(100) NOT NULL,
  `state` varchar(100) NOT NULL,
  `notes` text,
  `status` enum('0','1') NOT NULL DEFAULT '0' COMMENT '0=>activated,1=>deactivated',
  `created` datetime NOT NULL,
  `modified` datetime NOT NULL,
  `calendar_id` varchar(255) NOT NULL,
  `channel_id` text NOT NULL,
  `sync_token` text NOT NULL,
  PRIMARY KEY (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO `users` (`user_id`, `user_type`, `first_name`, `last_name`, `company`, `email`, `password`, `secondary_email`, `mobile_phone`, `landline_phone`, `address_1`, `address_2`, `suburb`, `post_code`, `state`, `notes`, `status`, `created`, `modified`, `calendar_id`, `channel_id`, `sync_token`) VALUES
(1,	'Admin',	'Tarvinder',	'Singh',	'Technocrats Horizons Compusoft',	'info@technocratshorizons.com',	'e10adc3949ba59abbe56e057f20f883e',	'info@technocratshorizons.com',	'9996668885',	'',	'Bharat Nagar Chowk',	'',	'Ludhiana',	'141001',	'punjab',	'',	'0',	'2017-11-25 23:01:38',	'2017-11-25 23:01:38',	'',	'',	''),
(65,	'Scanner',	'App ',	'Development',	'Technocratshorizons',	'appdevelopment50@gmail.com',	'9f722fbf768b2e247dfbae7bf6da9dbd',	'appdevelopment50@gmail.com',	'491570156',	NULL,	'Ludhiana Punjab India',	NULL,	'Ludhiana',	'141001',	'Punjab',	'Test account for testing',	'0',	'2018-01-05 16:56:15',	'2018-01-05 16:56:15',	'0cuqjhs53cvhiqh28uq3iu9qvs@group.calendar.google.com',	'n02T2RYJ-0jS2-ZWb2-MNtB-2Jr5ipbpI9bV',	'COj0m6OWwNgCEOj0m6OWwNgCGAU='),
(66,	'Client',	'Demo',	'Tester',	'DemoTester',	'demotester8@gmail.com',	'',	'',	'491015411',	'',	'Ludhiana Punjab India',	'',	'Ludhiana',	'141001',	'Punjab',	NULL,	'0',	'0000-00-00 00:00:00',	'0000-00-00 00:00:00',	'',	'',	''),
(67,	'Client',	'Test ',	'Client',	'TestClient',	'testclient@gmail.com',	'',	'',	'7845126398',	'',	'Ludhiana Punjab India',	'',	'Ludhiana',	'141001',	'Punjab',	NULL,	'0',	'0000-00-00 00:00:00',	'0000-00-00 00:00:00',	'',	'',	''),
(68,	'Client',	'KUmar',	'Agni',	'KumarAgni',	'kumaragni@gmail.com',	'',	'',	'145263789',	'',	'Ludhiana Punjab India',	'',	'Ludhiana',	'141001',	'Punjab',	NULL,	'0',	'0000-00-00 00:00:00',	'0000-00-00 00:00:00',	'',	'',	''),
(69,	'Client',	'Test',	'test',	'test',	'abc@gmail.com',	'',	'abc@gmail.com',	'111111111',	'11212121',	'1sn',	'kkhkjh',	'kjhjkhhk',	'212121',	'jhkjhkjhk',	NULL,	'0',	'0000-00-00 00:00:00',	'0000-00-00 00:00:00',	'',	'',	'');

-- 2018-01-05 09:28:11
