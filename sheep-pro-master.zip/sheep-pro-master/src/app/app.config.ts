﻿export const appConfig = {
    apiUrl: 'http://staging.technocratshorizons.com/sheeptimer/server/'
    //apiUrl: 'http://112.196.85.52/ram-timer/server/'
};