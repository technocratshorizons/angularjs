export * from './adminadd/adminadd.component';
export * from './adminlist/adminlist.component';