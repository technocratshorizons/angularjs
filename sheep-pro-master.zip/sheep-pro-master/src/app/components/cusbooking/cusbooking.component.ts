import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-cusbooking',
  templateUrl: './cusbooking.component.html',
  styleUrls: ['./cusbooking.component.css']
})
export class CusbookingComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
